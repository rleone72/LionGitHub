# IBM Content Cortex (ICCx) - DB2 Database Setup & Deployment Documentation

Dieses Dokument beschreibt die Architektur, Konfiguration, Berechtigungsvergabe und CI/CD-Deployment-Prozesse für die DB2-Datenbankobjekte von **IBM Content Cortex (ICCx)** bzw. **IBM FileNet Content Manager (FNCM / CP4BA)**.

---

## Inhaltsverzeichnis

1. [Übersicht & Architektur](#1-übersicht--architektur)
2. [Objekt-Referenz](#2-objekt-referenz)
   - [Bufferpool](#21-bufferpool)
   - [Schemas & Service-Benutzer](#22-schemas--service-benutzer)
   - [Tablespaces & Caching-Strategie](#23-tablespaces--caching-strategie)
   - [Berechtigungskonzept (Least Privilege)](#24-berechtigungskonzept-least-privilege)
3. [Parameter & Platzhalter](#3-parameter--platzhalter)
4. [Voraussetzungen](#4-voraussetzungen)
5. [Deployment-Methoden](#5-deployment-methoden)
   - [Methode A: CI/CD Shell-Wrapper (`deploy_iccx_db2.sh`)](#methode-a-cicd-shell-wrapper-deploy_iccx_db2sh)
   - [Methode B: Direkte DB2 CLP Ausführung via `sed`](#methode-b-direkte-db2-clp-ausführung-via-sed)
6. [CI/CD Pipeline-Integration](#6-cicd-pipeline-integration)
   - [GitLab CI/CD](#gitlab-cicd)
   - [GitHub Actions](#github-actions)
   - [Azure DevOps Pipelines](#azure-devops-pipelines)
   - [Jenkinsfile](#jenkinsfile)
7. [Verifikation & Qualitätssicherung](#7-verifikation--qualitätssicherung)
8. [Fehlerbehebung & Best Practices](#8-fehlerbehebung--best-practices)

---

## 1. Übersicht & Architektur

IBM Content Cortex (ICCx) nutzt die Enterprise-Content-Management-Engine von IBM FileNet Content Manager. Die Datenbankarchitektur gliedert sich in:

- **Global Configuration Database (GCD):** Zentrale Konfigurations- und Domain-Metadaten (`svcfndb2gcd<ENV>`).
- **IBM Content Navigator (ICN):** Web-Client Konfigurations- und Session-Datenbank (`svcfndb2icn<ENV>`).
- **Object Stores (OS):** Fachliche Dokumentenspeicher für Metadaten, Indexe, LOBs und Workflow-Tabellen:
  - **PERSON (`svcfndb2person<ENV>`):** Standard Object Store & Workflow / Process Engine (`PERSONVW`).
  - **LOGISTIK (`svcfndb2logistik<ENV>`):** Fachbereichs-Object-Store Logistik.
  - **UNTERNEHMEN (`svcfndb2unternehmen<ENV>`):** Fachbereichs-Object-Store Unternehmensdaten.

---

## 2. Objekt-Referenz

### 2.1 Bufferpool

FileNet Content Manager benötigt für Metadaten, Dokumenteigenschaften und Indizes eine Pagesize von **32 KB**.

| Name | Pagesize | Typ | Konfiguration |
| :--- | :--- | :--- | :--- |
| `AVAMDMSDBP32KB` | 32 KB (32768 Byte) | Automatisch | `IMMEDIATE SIZE AUTOMATIC PAGESIZE 32K` |

### 2.2 Schemas & Service-Benutzer

| Schema / User | Funktion / Komponente | Standard-Tablespaces |
| :--- | :--- | :--- |
| `svcfndb2icn<ENV>` | IBM Content Navigator Konfiguration | `TEMPSPACE1` (Default DB2 Tablespaces) |
| `svcfndb2gcd<ENV>` | FileNet GCD (Global Configuration DB) | `TEMPSPACE1` (Default DB2 Tablespaces) |
| `svcfndb2person<ENV>` | Object Store: Person & Workflow | `TS_PERSON_*`, `TS_PERSONVW_*` |
| `svcfndb2logistik<ENV>` | Object Store: Logistik | `TS_LOGI_*` |
| `svcfndb2unternehmen<ENV>` | Object Store: Unternehmen | `TS_UNTER_*` |

### 2.3 Tablespaces & Caching-Strategie

Zur Optimierung der I/O-Performance und Speichereffizienz von DB2 LUW gilt:
- **DATA & INDEX Tablespaces:** `NO FILE SYSTEM CACHING` (Direktzugriff über DB2 Bufferpool, Vermeidung von Double-Caching im OS).
- **LOB Tablespaces:** `FILE SYSTEM CACHING` (Vorteilhaft für große unformatierte Binärobjekte).

| Object Store | Tablespace Name | Typ | File System Caching |
| :--- | :--- | :--- | :--- |
| **PERSON** | `TS_PERSON_DAT_<ENV>` | Large Tablespace (32K) | `NO FILE SYSTEM CACHING` |
| | `TS_PERSON_IND_<ENV>` | Large Tablespace (32K) | `NO FILE SYSTEM CACHING` |
| | `TS_PERSON_LOB_<ENV>` | Large Tablespace (32K) | `FILE SYSTEM CACHING` |
| **PERSON VW** | `TS_PERSONVW_DAT_<ENV>` | Large Tablespace (32K) | `NO FILE SYSTEM CACHING` |
| | `TS_PERSONVW_IND_<ENV>` | Large Tablespace (32K) | `NO FILE SYSTEM CACHING` |
| | `TS_PERSONVW_LOB_<ENV>` | Large Tablespace (32K) | `FILE SYSTEM CACHING` |
| **LOGISTIK** | `TS_LOGI_DATA_<ENV>` | Large Tablespace (32K) | `NO FILE SYSTEM CACHING` |
| | `TS_LOGI_INDEX_<ENV>` | Large Tablespace (32K) | `NO FILE SYSTEM CACHING` |
| | `TS_LOGI_LOB_<ENV>` | Large Tablespace (32K) | `FILE SYSTEM CACHING` |
| **UNTERNEHMEN** | `TS_UNTER_DATA_<ENV>` | Large Tablespace (32K) | `NO FILE SYSTEM CACHING` |
| | `TS_UNTER_INDEX_<ENV>` | Large Tablespace (32K) | `NO FILE SYSTEM CACHING` |
| | `TS_UNTER_LOB_<ENV>` | Large Tablespace (32K) | `FILE SYSTEM CACHING` |

### 2.4 Berechtigungskonzept (Least Privilege)

Das Skript vergibt strikt die von IBM FileNet CPE und IBM Content Navigator benötigten Mindestberechtigungen:

1. **Datenbankebene:**
   - `GRANT CONNECT ON DATABASE TO USER <USER>`
   - `GRANT CREATETAB ON DATABASE TO USER <USER>`
   - `GRANT IMPLICIT_SCHEMA ON DATABASE TO USER <USER>`
2. **Katalogtabellen & Workload:**
   - `GRANT SELECT ON SYSIBM.SYSVERSIONS TO USER <USER>`
   - `GRANT SELECT ON SYSCAT.DATATYPES TO USER <USER>`
   - `GRANT SELECT ON SYSCAT.INDEXES TO USER <USER>`
   - `GRANT SELECT ON SYSIBM.SYSDUMMY1 TO USER <USER>`
   - `GRANT USAGE ON WORKLOAD SYSDEFAULTUSERWORKLOAD TO USER <USER>`
3. **Schemaebene:**
   - `CREATE SCHEMA <SCHEMA> AUTHORIZATION <USER>`
   - `GRANT CREATEIN, USAGE ON SCHEMA <SCHEMA> TO USER <USER>`
4. **Tablespaceebene:**
   - `GRANT USE OF TABLESPACE <TEMP_TS> TO USER <USER>` (für temporäre Operationen)
   - `GRANT USE OF TABLESPACE <TS_NAME> TO USER <USER>` (dedizierte Zuweisung je Object Store)

---

## 3. Parameter & Platzhalter

Im SQL-Template [`iccx_db2_setup.sql`](iccx_db2_setup.sql) sind folgende Variablen definiert:

| Platzhalter | Beschreibung | Beispielwerte |
| :--- | :--- | :--- |
| `@DBNAME@` | Name der Ziel-DB2-Datenbank | `ICCXDB`, `FNP8DB`, `CP4BADB` |
| `@ENV@` | Suffix der Zielumgebung | `int`, `tst`, `prd`, `dev`, `eg1` |
| `@TEMP_TS@` | Name des temporären 32K/System-Tablespaces | `TEMPSPACE1`, `TS_TEMP_32K` |

---

## 4. Voraussetzungen

1. **DB2 Instanz & Datenbank:** Die DB2-Datenbank (z.B. `ICCXDB`) muss bereits existieren und über Automatic Storage verfügen.
2. **Betriebssystem- / LDAP-Benutzer:** DB2 LUW nutzt die Authentifizierung des Betriebssystems oder zentralen Directory-Servers (LDAP/AD). Die Benutzer `svcfndb2icn<ENV>`, `svcfndb2gcd<ENV>`, `svcfndb2logistik<ENV>`, `svcfndb2person<ENV>`, `svcfndb2unternehmen<ENV>` müssen vor der Skriptausführung auf OS-/LDAP-Ebene angelegt worden sein.
3. **Ausführender Benutzer:** Der ausführende Administrator benötigt `SECADM` / `DBADM` bzw. `ACCESSCTRL` Rechte, um Bufferpools, Tablespaces, Schemas und Berechtigungen zu erstellen.

---

## 5. Deployment-Methoden

### Methode A: CI/CD Shell-Wrapper (`deploy_iccx_db2.sh`)

Das mitgelieferte Skript [`deploy_iccx_db2.sh`](deploy_iccx_db2.sh) führt die Substitution und DB2-Ausführung automatisiert durch.

```bash
# Ausführungsrechte setzen
chmod +x deploy_iccx_db2.sh

# Syntax: ./deploy_iccx_db2.sh <DBNAME> <ENV_SUFFIX> [TEMP_TABLESPACE]
./deploy_iccx_db2.sh ICCXDB int TEMPSPACE1
```

**Was das Skript macht:**
1. Validiert die übergebenen Eingabeparameter.
2. Ersetzt `@DBNAME@`, `@ENV@` und `@TEMP_TS@` in [`iccx_db2_setup.sql`](iccx_db2_setup.sql).
3. Generiert eine versionssichere Datei `iccx_db2_setup_<ENV>.generated.sql`.
4. Führt das SQL-Skript über `db2 -tvf` aus und speichert alle Meldungen in `iccx_db2_setup_<ENV>.log`.
5. Prüft den Rückgabewert (Return Code) für CI/CD-Pipelines.

### Methode B: Direkte DB2 CLP Ausführung via `sed`

Falls kein Bash-Wrapper verwendet werden soll:

```bash
# 1. SQL vorbereiten
sed -e 's/@DBNAME@/ICCXDB/g' \
    -e 's/@ENV@/int/g' \
    -e 's/@TEMP_TS@/TEMPSPACE1/g' \
    iccx_db2_setup.sql > run_int.sql

# 2. Ausführen mit DB2 Command Line Processor
db2 -tvf run_int.sql -z run_int.log
```

---

## 6. CI/CD Pipeline-Integration

### GitLab CI/CD

```yaml
stages:
  - deploy-db

deploy_iccx_db2_int:
  stage: deploy-db
  tags:
    - db2-runner
  variables:
    DB_NAME: "ICCXDB"
    ENV_NAME: "int"
    TEMP_TS: "TEMPSPACE1"
  script:
    - chmod +x ./deploy_iccx_db2.sh
    - ./deploy_iccx_db2.sh "${DB_NAME}" "${ENV_NAME}" "${TEMP_TS}"
  artifacts:
    when: always
    paths:
      - iccx_db2_setup_*.log
      - iccx_db2_setup_*.generated.sql
  only:
    - develop

deploy_iccx_db2_prd:
  stage: deploy-db
  tags:
    - db2-runner
  variables:
    DB_NAME: "ICCXDB"
    ENV_NAME: "prd"
    TEMP_TS: "TEMPSPACE1"
  script:
    - chmod +x ./deploy_iccx_db2.sh
    - ./deploy_iccx_db2.sh "${DB_NAME}" "${ENV_NAME}" "${TEMP_TS}"
  artifacts:
    when: always
    paths:
      - iccx_db2_setup_*.log
      - iccx_db2_setup_*.generated.sql
  when: manual
  only:
    - main
```

### GitHub Actions

```yaml
name: Deploy ICCx DB2 Objects

on:
  workflow_dispatch:
    inputs:
      environment:
        description: 'Zielumgebung (int, tst, prd)'
        required: true
        default: 'int'
      dbname:
        description: 'DB2 Datenbankname'
        required: true
        default: 'ICCXDB'

jobs:
  deploy:
    runs-on: [self-hosted, db2-client]
    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Run DB2 Setup
        run: |
          chmod +x ./deploy_iccx_db2.sh
          ./deploy_iccx_db2.sh "${{ github.event.inputs.dbname }}" "${{ github.event.inputs.environment }}" "TEMPSPACE1"

      - name: Upload Logs
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: db2-deployment-logs-${{ github.event.inputs.environment }}
          path: |
            iccx_db2_setup_*.log
            iccx_db2_setup_*.generated.sql
```

### Azure DevOps Pipelines

```yaml
trigger: none

parameters:
  - name: dbName
    displayName: "DB2 Database Name"
    type: string
    default: "ICCXDB"
  - name: envSuffix
    displayName: "Environment Suffix"
    type: string
    default: "int"
    values:
      - dev
      - int
      - tst
      - prd

jobs:
- job: DeployDB2
  pool:
    name: 'DB2-Agent-Pool'
  steps:
  - script: |
      chmod +x ./deploy_iccx_db2.sh
      ./deploy_iccx_db2.sh "${{ parameters.dbName }}" "${{ parameters.envSuffix }}" "TEMPSPACE1"
    displayName: 'Execute DB2 Setup Script'
  - task: PublishBuildArtifacts@1
    condition: always()
    inputs:
      PathtoPublish: 'iccx_db2_setup_${{ parameters.envSuffix }}.log'
      ArtifactName: 'DB2-Logs'
      publishLocation: 'Container'
```

### Jenkinsfile

```groovy
pipeline {
    agent { label 'db2-agent' }
    parameters {
        string(name: 'DB_NAME', defaultValue: 'ICCXDB', description: 'DB2 Datenbankname')
        choice(name: 'ENV_SUFFIX', choices: ['int', 'tst', 'prd', 'dev'], description: 'Umgebungssuffix')
        string(name: 'TEMP_TS', defaultValue: 'TEMPSPACE1', description: 'Temp Tablespace')
    }
    stages {
        stage('Deploy DB2 Objects') {
            steps {
                sh '''
                    chmod +x ./deploy_iccx_db2.sh
                    ./deploy_iccx_db2.sh "${DB_NAME}" "${ENV_SUFFIX}" "${TEMP_TS}"
                '''
            }
        }
    }
    post {
        always {
            archiveArtifacts artifacts: 'iccx_db2_setup_*.log, iccx_db2_setup_*.generated.sql', allowEmptyArchive: true
        }
    }
}
```

---

## 7. Verifikation & Qualitätssicherung

Nach dem Deployment kann die korrekte Erstellung aller Komponenten mit folgenden Abfragen validiert werden:

```sql
CONNECT TO <DBNAME>;

-- 1. Bufferpool pruefen (PAGESIZE muss 32768 sein)
SELECT SUBSTR(BPNAME,1,20) AS BPNAME, PAGESIZE, NPAGES 
FROM SYSCAT.BUFFERPOOLS 
WHERE BPNAME = 'AVAMDMSDBP32KB';

-- 2. Schemas pruefen
SELECT SCHEMANAME, OWNER, DEFINER 
FROM SYSCAT.SCHEMATA 
WHERE SCHEMANAME LIKE 'SVCFNDB2%';

-- 3. Tablespaces und Caching pruefen
SELECT SUBSTR(TBSPACE,1,28) AS TBSPACE, TBSPACETYPE, DATATYPE, PAGESIZE, FSCACHING, BUFFERPOOLID
FROM SYSCAT.TABLESPACES 
WHERE TBSPACE LIKE 'TS_%'
ORDER BY TBSPACE;

-- 4. Datenbank-Basisberechtigungen pruefen
SELECT GRANTEE, DBADMAUTH, CREATETABAUTH, IMPLSCHEMAAUTH, CONNECTAUTH 
FROM SYSCAT.DBAUTH 
WHERE GRANTEE LIKE 'SVCFNDB2%';

-- 5. Tablespace-Nutzungsrechte pruefen
SELECT SUBSTR(TBSPACE,1,28) AS TBSPACE, GRANTEE, USEAUTH 
FROM SYSCAT.TBSPACETABAUTH 
WHERE GRANTEE LIKE 'SVCFNDB2%'
ORDER BY GRANTEE, TBSPACE;

CONNECT RESET;
```

---

## 8. Fehlerbehebung & Best Practices

| Symptom / Fehler | Ursache | Lösung |
| :--- | :--- | :--- |
| `SQL0204N ... "AVAMDMSDBP32KB" is an undefined name` | Der Bufferpool wurde vor der Tablespace-Erstellung nicht angelegt oder ist fehlgeschlagen. | Prüfen, ob `CREATE BUFFERPOOL` erfolgreich durchlief (`SYSCAT.BUFFERPOOLS`). |
| `SQL0551N ... does not have required authorization` | Der ausführende Benutzer besitzt nicht ausreichend Rechte (z.B. fehlendes `SECADM` / `DBADM`). | Skript mit einem privilegierten DB2-Admin-Account (`db2inst1` oder administrativer CI/CD-Service-Account) ausführen. |
| `SQL0289N Unable to allocate new pages in table space` | DB2 Automatic Storage Speicherpfad ist voll oder nicht konfiguriert. | Plattenplatz des DB2 Storage Groups prüfen (`db2pd -storagepools`). |
| `SQL0567N ... invalid authorization ID` | Der angegebene Benutzername ist im OS/LDAP unbekannt oder überschreitet die DB2-Längenbegrenzung. | Sicherstellen, dass die Service-Accounts im LDAP/OS existieren und in Klein-/Großschreibung übereinstimmen. |
