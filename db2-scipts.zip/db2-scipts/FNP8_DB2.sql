----------------------------------------------
-- DRVRHOS - CP4BA Authoring Environment
-- KORRIGIERTE, LAUFFAEHIGE VERSION
--
-- Referenzen:
-- https://www.ibm.com/docs/en/filenet-p8-platform/5.7.0?topic=vtdluwiifp-creating-db2-database-table-spaces-content-platform-engine-object-store
-- https://www.ibm.com/docs/en/cloud-paks/cp-biz-automation/25.0.0?topic=scripts-creating-db2-database
--
-- Aenderungen gegenueber dem Original:
--  1. UPDATE SYSIBM.SYSDBAUTH entfernt (Systemkatalog ist nicht per UPDATE
--     beschreibbar; die Fehlermeldung waere SQL0551N/nicht aktualisierbare View).
--     SCHEMAAUTH ergibt sich automatisch aus DBADM.
--  2. CREATE SCHEMA ... AUTHORIZATION ... vor die GRANT CREATEIN/USAGE ON SCHEMA
--     Anweisungen gesetzt, da die Schemas vorher nicht existierten (SQL0204N).
--  3. Explizite 32K-Bufferpools angelegt statt sich auf IBMDEFAULTBP zu verlassen
--     (IBMDEFAULTBP hat nur dann 32K, wenn die DB selbst mit PAGESIZE 32768
--     erstellt wurde).
--  4. CONNECT TO DBNAME aktiviert (bitte DBNAME unten ersetzen). Achtung:
--     FNGCD, FNOS01 und ICNCFG01 sind in einer Standard-FileNet-P8-Installation
--     eigentlich SEPARATE DB2-Datenbanken. Dieses Skript geht (wie das Original)
--     davon aus, dass alle Schemas in EINER gemeinsamen Datenbank liegen. Falls
--     du tatsaechlich drei getrennte Datenbanken willst, siehe Hinweis am Ende.
--  5. Grants fuer den Benutzer M_ICMCHS01 entfernt, da im Original weder
--     Tablespaces noch ein Schema fuer ihn definiert waren (verwaister Rest
--     einer anderen Vorlage). Falls benoetigt, siehe Hinweis am Ende.
----------------------------------------------

-- Verbindung zur Zieldatenbank herstellen (DBNAME ersetzen!)
CONNECT TO DBNAME;

----------------------------------------------
-- Bufferpools fuer 32K-Tablespaces
----------------------------------------------

CREATE BUFFERPOOL BP32K IMMEDIATE SIZE AUTOMATIC PAGESIZE 32 K;

----------------------------------------------
-- FNGCD - Global Configuration Database
----------------------------------------------

CREATE TABLESPACE TS_FNGCD_DATA
    PAGESIZE 32 K
    MANAGED BY AUTOMATIC STORAGE
    EXTENTSIZE 32
    PREFETCHSIZE 32
    BUFFERPOOL BP32K;

CREATE USER TEMPORARY TABLESPACE TS_FNGCD_TEMP
    PAGESIZE 32 K
    MANAGED BY AUTOMATIC STORAGE USING STOGROUP IBMDB2UTEMPSG1
    EXTENTSIZE 32
    PREFETCHSIZE 32
    BUFFERPOOL BP32K;

----------------------------------------------
-- FNOS01 - Object Store
----------------------------------------------

CREATE TABLESPACE TS_FNOS01_INDEX
    PAGESIZE 32 K
    MANAGED BY AUTOMATIC STORAGE
    EXTENTSIZE 32
    PREFETCHSIZE 32
    BUFFERPOOL BP32K;

CREATE TABLESPACE TS_FNOS01_DATA
    PAGESIZE 32 K
    MANAGED BY AUTOMATIC STORAGE
    EXTENTSIZE 32
    PREFETCHSIZE 32
    BUFFERPOOL BP32K;

CREATE TABLESPACE TS_FNOS01_LOB
    PAGESIZE 32 K
    MANAGED BY AUTOMATIC STORAGE
    EXTENTSIZE 32
    PREFETCHSIZE 32
    BUFFERPOOL BP32K;

-- Fuer Views
CREATE TABLESPACE TS_FNOS01VW_DATA
    PAGESIZE 32 K
    MANAGED BY AUTOMATIC STORAGE
    EXTENTSIZE 32
    PREFETCHSIZE 32
    BUFFERPOOL BP32K;

CREATE TABLESPACE TS_FNOS01VW_INDEX
    PAGESIZE 32 K
    MANAGED BY AUTOMATIC STORAGE
    EXTENTSIZE 32
    PREFETCHSIZE 32
    BUFFERPOOL BP32K;

CREATE TABLESPACE TS_FNOS01VW_LOB
    PAGESIZE 32 K
    MANAGED BY AUTOMATIC STORAGE
    EXTENTSIZE 32
    PREFETCHSIZE 32
    BUFFERPOOL BP32K;

CREATE USER TEMPORARY TABLESPACE TS_FNOS01_TEMP
    PAGESIZE 32 K
    MANAGED BY AUTOMATIC STORAGE USING STOGROUP IBMDB2UTEMPSG1
    EXTENTSIZE 32
    PREFETCHSIZE 32
    BUFFERPOOL BP32K;

-------------------------------------------------------
-- ICNCFG01 - Content Navigator Configuration Database
-------------------------------------------------------

CREATE TABLESPACE TS_ICNCFG01_DATA
    PAGESIZE 32 K
    MANAGED BY AUTOMATIC STORAGE
    EXTENTSIZE 32
    PREFETCHSIZE 32
    BUFFERPOOL BP32K;

CREATE USER TEMPORARY TABLESPACE TS_ICNCFG01_TEMP
    PAGESIZE 32 K
    MANAGED BY AUTOMATIC STORAGE USING STOGROUP IBMDB2UTEMPSG1
    EXTENTSIZE 32
    PREFETCHSIZE 32
    BUFFERPOOL BP32K;

----------------------------------------------
-- Grundberechtigungen (CONNECT/CREATETAB) zuerst,
-- damit die impliziten Schemas ueberhaupt angelegt werden koennen
----------------------------------------------

-- M_FNGCD
GRANT CONNECT ON DATABASE TO USER M_FNGCD;
GRANT CREATETAB ON DATABASE TO USER M_FNGCD;
GRANT CREATE_NOT_FENCED ON DATABASE TO USER M_FNGCD;
GRANT IMPLICIT_SCHEMA ON DATABASE TO USER M_FNGCD;
GRANT LOAD ON DATABASE TO USER M_FNGCD;
GRANT CREATE_EXTERNAL_ROUTINE ON DATABASE TO USER M_FNGCD;
GRANT QUIESCE_CONNECT ON DATABASE TO USER M_FNGCD;
GRANT DBADM ON DATABASE TO USER M_FNGCD;

-- M_FNOS01
GRANT CONNECT ON DATABASE TO USER M_FNOS01;
GRANT CREATETAB ON DATABASE TO USER M_FNOS01;
GRANT CREATE_NOT_FENCED ON DATABASE TO USER M_FNOS01;
GRANT IMPLICIT_SCHEMA ON DATABASE TO USER M_FNOS01;
GRANT LOAD ON DATABASE TO USER M_FNOS01;
GRANT CREATE_EXTERNAL_ROUTINE ON DATABASE TO USER M_FNOS01;
GRANT QUIESCE_CONNECT ON DATABASE TO USER M_FNOS01;
GRANT DBADM ON DATABASE TO USER M_FNOS01;

-- M_ICNCFG01
GRANT CONNECT ON DATABASE TO USER M_ICNCFG01;
GRANT CREATETAB ON DATABASE TO USER M_ICNCFG01;
GRANT CREATE_NOT_FENCED ON DATABASE TO USER M_ICNCFG01;
GRANT IMPLICIT_SCHEMA ON DATABASE TO USER M_ICNCFG01;
GRANT LOAD ON DATABASE TO USER M_ICNCFG01;
GRANT CREATE_EXTERNAL_ROUTINE ON DATABASE TO USER M_ICNCFG01;
GRANT QUIESCE_CONNECT ON DATABASE TO USER M_ICNCFG01;
GRANT DBADM ON DATABASE TO USER M_ICNCFG01;

----------------------------------------------
-- Schemas explizit anlegen (statt spaeter implizit ueber SYSDBAUTH),
-- damit die anschliessenden GRANT ... ON SCHEMA Anweisungen funktionieren
----------------------------------------------

CREATE SCHEMA M_FNGCD AUTHORIZATION M_FNGCD;
CREATE SCHEMA M_FNOS01 AUTHORIZATION M_FNOS01;
CREATE SCHEMA M_ICNCFG01 AUTHORIZATION M_ICNCFG01;

GRANT CREATEIN ON SCHEMA M_FNGCD TO USER M_FNGCD;
GRANT USAGE ON SCHEMA M_FNGCD TO USER M_FNGCD;

GRANT CREATEIN ON SCHEMA M_FNOS01 TO USER M_FNOS01;
GRANT USAGE ON SCHEMA M_FNOS01 TO USER M_FNOS01;

GRANT CREATEIN ON SCHEMA M_ICNCFG01 TO USER M_ICNCFG01;
GRANT USAGE ON SCHEMA M_ICNCFG01 TO USER M_ICNCFG01;

----------------------------------------------
-- Tablespace-Nutzung zuweisen
----------------------------------------------

-- M_FNGCD
GRANT USE OF TABLESPACE TS_FNGCD_DATA TO USER M_FNGCD;
GRANT USE OF TABLESPACE TS_FNGCD_TEMP TO USER M_FNGCD;

-- M_FNOS01
GRANT USE OF TABLESPACE TS_FNOS01_DATA TO USER M_FNOS01;
GRANT USE OF TABLESPACE TS_FNOS01_INDEX TO USER M_FNOS01;
GRANT USE OF TABLESPACE TS_FNOS01_LOB TO USER M_FNOS01;
GRANT USE OF TABLESPACE TS_FNOS01VW_DATA TO USER M_FNOS01;
GRANT USE OF TABLESPACE TS_FNOS01VW_INDEX TO USER M_FNOS01;
GRANT USE OF TABLESPACE TS_FNOS01VW_LOB TO USER M_FNOS01;
GRANT USE OF TABLESPACE TS_FNOS01_TEMP TO USER M_FNOS01;

-- M_ICNCFG01
GRANT USE OF TABLESPACE TS_ICNCFG01_DATA TO USER M_ICNCFG01;
GRANT USE OF TABLESPACE TS_ICNCFG01_TEMP TO USER M_ICNCFG01;

----------------------------------------------
-- Commit
----------------------------------------------

COMMIT;

CONNECT RESET;

----------------------------------------------
-- Hinweise:
-- 1. DBNAME oben im CONNECT-Statement durch den tatsaechlichen Datenbanknamen ersetzen.
-- 2. Die Benutzer M_FNGCD, M_FNOS01, M_ICNCFG01 muessen bereits auf OS-/LDAP-Ebene
--    existieren; DB2 LUW legt Datenbankbenutzer nicht per SQL an.
-- 3. PAGESIZE/BUFFERPOOL bei Bedarf an eure Storage-Vorgaben anpassen.
-- 4. Fuer Produktivumgebungen ggf. dedizierte Bufferpools mit fester statt
--    automatischer Groesse verwenden (SIZE <n> statt SIZE AUTOMATIC).
-- 5. GRANT DBADM ist eine sehr weitreichende Berechtigung (voller DB-Admin).
--    Das entspricht dem, was IBM in vielen offiziellen P8-Installationsskripten
--    tatsaechlich vorsieht, pruefe aber, ob euer Sicherheitskonzept das zulaesst.
-- 6. M_ICMCHS01 war im Originalskript nur in den GRANT-Anweisungen vorhanden,
--    aber ohne zugehoerige Tablespaces/Schema - vermutlich ein Rest aus einer
--    anderen Vorlage (z. B. Case History). Falls dieser Benutzer tatsaechlich
--    gebraucht wird, ergaenze fuer ihn analog zu den anderen: eigene
--    Tablespaces, CREATE SCHEMA, GRANT ... ON SCHEMA und GRANT USE OF TABLESPACE.
-- 7. Achtung: In einer klassischen FileNet-P8-Installation sind GCD, Object Store
--    und ICN-Konfigurationsdatenbank normalerweise DREI SEPARATE DB2-Datenbanken,
--    nicht drei Schemas in einer Datenbank. Falls das bei euch der Fall ist,
--    muss dieses Skript in drei Teile mit jeweils eigenem
--    "CONNECT TO <jeweilige DB>; ... CONNECT RESET;" aufgeteilt werden.
--
-- Database Summary:
-- - M_FNGCD: Global Configuration Database (1 Data-Tablespace)
-- - M_FNOS01: Object Store (6 Tablespaces: data, index, lob, vw_data, vw_index, vw_lob)
-- - M_ICNCFG01: Content Navigator Configuration Database (1 Data-Tablespace)
----------------------------------------------
