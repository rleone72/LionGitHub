#!/usr/bin/env bash
# https://www.ibm.com/docs/en/content-cortex/5.6.0?topic=ccpeda-creating-content-platform-engine-database-user-db2-linux-unix-windows
# =============================================================================
# Skript:       deploy_iccx_db2.sh
# Beschreibung: CI/CD Deployment-Wrapper fuer die IBM Content Cortex DB2-Objekte
#
# Verwendung:
#   ./deploy_iccx_db2.sh <DBNAME> <ENV_SUFFIX> [TEMP_TABLESPACE]
#
# Beispiel:
#   ./deploy_iccx_db2.sh ICCXDB int TEMPSPACE1
# =============================================================================

set -euo pipefail

DBNAME="${1:-}"
ENV_SUFFIX="${2:-}"
TEMP_TS="${3:-TEMPSPACE1}"

if [ -z "${DBNAME}" ] || [ -z "${ENV_SUFFIX}" ]; then
    echo "FEHLER: Fehlende Parameter."
    echo "Verwendung: $0 <DBNAME> <ENV_SUFFIX> [TEMP_TABLESPACE]"
    echo "Beispiel:   $0 ICCXDB int TEMPSPACE1"
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SQL_TEMPLATE="${SCRIPT_DIR}/iccx_db2_setup.sql"
GENERATED_SQL="${SCRIPT_DIR}/iccx_db2_setup_${ENV_SUFFIX}.generated.sql"
LOG_FILE="${SCRIPT_DIR}/iccx_db2_setup_${ENV_SUFFIX}.log"

if [ ! -f "${SQL_TEMPLATE}" ]; then
    echo "FEHLER: SQL-Template '${SQL_TEMPLATE}' nicht gefunden."
    exit 1
fi

echo "============================================================"
echo "ICCx DB2 Deployment"
echo "  Datenbank:           ${DBNAME}"
echo "  Umgebung / Suffix:   ${ENV_SUFFIX}"
echo "  Temp Tablespace:     ${TEMP_TS}"
echo "  SQL-Template:        ${SQL_TEMPLATE}"
echo "  Ziel-SQL:            ${GENERATED_SQL}"
echo "  Log-Datei:           ${LOG_FILE}"
echo "============================================================"

# Platzhalter ersetzen
sed \
    -e "s/@DBNAME@/${DBNAME}/g" \
    -e "s/@ENV@/${ENV_SUFFIX}/g" \
    -e "s/@TEMP_TS@/${TEMP_TS}/g" \
    "${SQL_TEMPLATE}" > "${GENERATED_SQL}"

echo "[OK] SQL-Skript erfolgreich generiert."

# DB2 Ausfuehrung
echo "Starte DB2 CLP Ausfuehrung..."
if command -v db2 >/dev/null 2>&1; then
    db2 -tvf "${GENERATED_SQL}" -z "${LOG_FILE}"
    RC=$?
    if [ $RC -eq 0 ]; then
        echo "[ERFOLG] Alle DB2-Objekte wurden erfolgreich erstellt."
    else
        echo "[WARNUNG/FEHLER] DB2 meldet Exit-Code ${RC}. Pruefe ${LOG_FILE} auf Details."
        exit $RC
    fi
else
    echo "[HINWEIS] DB2 CLI ('db2') ist in dieser Umgebung nicht im PATH."
    echo "Das generierte Skript '${GENERATED_SQL}' kann manuell auf dem DB2-Server ausgefuehrt werden:"
    echo "  db2 -tvf ${GENERATED_SQL} -z ${LOG_FILE}"
fi
