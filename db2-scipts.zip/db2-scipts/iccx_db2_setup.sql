-- =============================================================================
-- Skript:        iccx_db2_setup.sql
-- Beschreibung:  Erstellung aller DB2-Datenbankobjekte fuer IBM Content Cortex (ICCx)
--                / IBM FileNet Content Manager (FNCM / CP4BA)
--
-- Enthaltene Komponenten:
--   - 32K Bufferpool: AVAMDMSDBP32KB
--   - Schemas & Benutzer:
--       * svcfndb2icn<ENV>         (IBM Content Navigator Konfigurations-DB)
--       * svcfndb2gcd<ENV>         (Global Configuration Database / GCD)
--       * svcfndb2logistik<ENV>    (Object Store: Logistik)
--       * svcfndb2person<ENV>      (Object Store: Person inkl. Workflow/VW)
--       * svcfndb2unternehmen<ENV> (Object Store: Unternehmen)
--   - Tablespaces:
--       * PERSON:      TS_PERSON_DAT_<ENV>, TS_PERSON_IND_<ENV>, TS_PERSON_LOB_<ENV>
--       * PERSONVW:    TS_PERSONVW_DAT_<ENV>, TS_PERSONVW_IND_<ENV>, TS_PERSONVW_LOB_<ENV>
--       * LOGISTIK:    TS_LOGI_DATA_<ENV>, TS_LOGI_INDEX_<ENV>, TS_LOGI_LOB_<ENV>
--       * UNTERNEHMEN: TS_UNTER_DATA_<ENV>, TS_UNTER_INDEX_<ENV>, TS_UNTER_LOB_<ENV>
--   - Rechte & Berechtigungen (Minimum-Privilege-Prinzip fuer FileNet CPE & ICN)
--
-- Verwendung / Platzhalter:
--   Vor der Ausfuehrung muessen folgende Platzhalter ersetzt werden:
--     @DBNAME@     -> Name der DB2-Datenbank (z.B. ICCXDB)
--     @ENV@        -> Umgebungssuffix (z.B. int, tst, prd, dev)
--     @TEMP_TS@    -> Name des temporaeren Tablespaces (Default: TEMPSPACE1)
--
-- CLI Ausfuehrung:
--   sed -e 's/@DBNAME@/MYDB/g' -e 's/@ENV@/int/g' -e 's/@TEMP_TS@/TEMPSPACE1/g' iccx_db2_setup.sql > run.sql
--   db2 -tvf run.sql -z run.log
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 0. Verbindung zur Zieldatenbank herstellen
-- -----------------------------------------------------------------------------
CONNECT TO @DBNAME@;

-- -----------------------------------------------------------------------------
-- 1. Bufferpool erstellen (32 KB Pagesize fuer FileNet Content Manager / ICCx)
-- -----------------------------------------------------------------------------
-- Hinweis: Falls der Bufferpool bereits existiert, diesen Block ueberspringen
CREATE BUFFERPOOL AVAMDMSDBP32KB
    IMMEDIATE
    SIZE AUTOMATIC
    PAGESIZE 32K;

-- -----------------------------------------------------------------------------
-- 2. Schemas erstellen und Berechtigungen auf Schema-Ebene vergeben
-- -----------------------------------------------------------------------------
CREATE SCHEMA svcfndb2icn@ENV@ AUTHORIZATION svcfndb2icn@ENV@;
CREATE SCHEMA svcfndb2gcd@ENV@ AUTHORIZATION svcfndb2gcd@ENV@;
CREATE SCHEMA svcfndb2logistik@ENV@ AUTHORIZATION svcfndb2logistik@ENV@;
CREATE SCHEMA svcfndb2person@ENV@ AUTHORIZATION svcfndb2person@ENV@;
CREATE SCHEMA svcfndb2unternehmen@ENV@ AUTHORIZATION svcfndb2unternehmen@ENV@;

GRANT CREATEIN, USAGE ON SCHEMA svcfndb2icn@ENV@ TO USER svcfndb2icn@ENV@;
GRANT CREATEIN, USAGE ON SCHEMA svcfndb2gcd@ENV@ TO USER svcfndb2gcd@ENV@;
GRANT CREATEIN, USAGE ON SCHEMA svcfndb2logistik@ENV@ TO USER svcfndb2logistik@ENV@;
GRANT CREATEIN, USAGE ON SCHEMA svcfndb2person@ENV@ TO USER svcfndb2person@ENV@;
GRANT CREATEIN, USAGE ON SCHEMA svcfndb2unternehmen@ENV@ TO USER svcfndb2unternehmen@ENV@;

-- -----------------------------------------------------------------------------
-- 3. Tablespaces erstellen
-- -----------------------------------------------------------------------------

-- 3.1 PERSON Tablespaces (Standard Object Store)
CREATE LARGE TABLESPACE TS_PERSON_DAT_@ENV@
    PAGESIZE 32K
    MANAGED BY AUTOMATIC STORAGE
    AUTORESIZE YES
    BUFFERPOOL AVAMDMSDBP32KB
    NO FILE SYSTEM CACHING;

CREATE LARGE TABLESPACE TS_PERSON_IND_@ENV@
    PAGESIZE 32K
    MANAGED BY AUTOMATIC STORAGE
    AUTORESIZE YES
    BUFFERPOOL AVAMDMSDBP32KB
    NO FILE SYSTEM CACHING;

CREATE LARGE TABLESPACE TS_PERSON_LOB_@ENV@
    PAGESIZE 32K
    MANAGED BY AUTOMATIC STORAGE
    AUTORESIZE YES
    BUFFERPOOL AVAMDMSDBP32KB
    FILE SYSTEM CACHING;

-- 3.2 PERSONVW Tablespaces (Workflow / Process Engine / Views)
CREATE LARGE TABLESPACE TS_PERSONVW_DAT_@ENV@
    PAGESIZE 32K
    MANAGED BY AUTOMATIC STORAGE
    AUTORESIZE YES
    BUFFERPOOL AVAMDMSDBP32KB
    NO FILE SYSTEM CACHING;

CREATE LARGE TABLESPACE TS_PERSONVW_IND_@ENV@
    PAGESIZE 32K
    MANAGED BY AUTOMATIC STORAGE
    AUTORESIZE YES
    BUFFERPOOL AVAMDMSDBP32KB
    NO FILE SYSTEM CACHING;

CREATE LARGE TABLESPACE TS_PERSONVW_LOB_@ENV@
    PAGESIZE 32K
    MANAGED BY AUTOMATIC STORAGE
    AUTORESIZE YES
    BUFFERPOOL AVAMDMSDBP32KB
    FILE SYSTEM CACHING;

-- 3.3 LOGISTIK Tablespaces
CREATE LARGE TABLESPACE TS_LOGI_DATA_@ENV@
    PAGESIZE 32K
    MANAGED BY AUTOMATIC STORAGE
    AUTORESIZE YES
    BUFFERPOOL AVAMDMSDBP32KB
    NO FILE SYSTEM CACHING;

CREATE LARGE TABLESPACE TS_LOGI_INDEX_@ENV@
    PAGESIZE 32K
    MANAGED BY AUTOMATIC STORAGE
    AUTORESIZE YES
    BUFFERPOOL AVAMDMSDBP32KB
    NO FILE SYSTEM CACHING;

CREATE LARGE TABLESPACE TS_LOGI_LOB_@ENV@
    PAGESIZE 32K
    MANAGED BY AUTOMATIC STORAGE
    AUTORESIZE YES
    BUFFERPOOL AVAMDMSDBP32KB
    FILE SYSTEM CACHING;

-- 3.4 UNTERNEHMEN Tablespaces
CREATE LARGE TABLESPACE TS_UNTER_DATA_@ENV@
    PAGESIZE 32K
    MANAGED BY AUTOMATIC STORAGE
    AUTORESIZE YES
    BUFFERPOOL AVAMDMSDBP32KB
    NO FILE SYSTEM CACHING;

CREATE LARGE TABLESPACE TS_UNTER_INDEX_@ENV@
    PAGESIZE 32K
    MANAGED BY AUTOMATIC STORAGE
    AUTORESIZE YES
    BUFFERPOOL AVAMDMSDBP32KB
    NO FILE SYSTEM CACHING;

CREATE LARGE TABLESPACE TS_UNTER_LOB_@ENV@
    PAGESIZE 32K
    MANAGED BY AUTOMATIC STORAGE
    AUTORESIZE YES
    BUFFERPOOL AVAMDMSDBP32KB
    FILE SYSTEM CACHING;

-- -----------------------------------------------------------------------------
-- 4. Datenbank-Basisberechtigungen fuer Service-Accounts vergeben
--    (IBM FileNet CPE & Content Navigator Mindestanforderungen)
-- -----------------------------------------------------------------------------

-- 4.1 svcfndb2icn@ENV@ (Navigator)
GRANT CONNECT ON DATABASE TO USER svcfndb2icn@ENV@;
GRANT CREATETAB ON DATABASE TO USER svcfndb2icn@ENV@;
GRANT IMPLICIT_SCHEMA ON DATABASE TO USER svcfndb2icn@ENV@;
GRANT SELECT ON SYSIBM.SYSVERSIONS TO USER svcfndb2icn@ENV@;
GRANT SELECT ON SYSCAT.DATATYPES TO USER svcfndb2icn@ENV@;
GRANT SELECT ON SYSCAT.INDEXES TO USER svcfndb2icn@ENV@;
GRANT SELECT ON SYSIBM.SYSDUMMY1 TO USER svcfndb2icn@ENV@;
GRANT USAGE ON WORKLOAD SYSDEFAULTUSERWORKLOAD TO USER svcfndb2icn@ENV@;
GRANT USE OF TABLESPACE @TEMP_TS@ TO USER svcfndb2icn@ENV@;

-- 4.2 svcfndb2gcd@ENV@ (GCD)
GRANT CONNECT ON DATABASE TO USER svcfndb2gcd@ENV@;
GRANT CREATETAB ON DATABASE TO USER svcfndb2gcd@ENV@;
GRANT IMPLICIT_SCHEMA ON DATABASE TO USER svcfndb2gcd@ENV@;
GRANT SELECT ON SYSIBM.SYSVERSIONS TO USER svcfndb2gcd@ENV@;
GRANT SELECT ON SYSCAT.DATATYPES TO USER svcfndb2gcd@ENV@;
GRANT SELECT ON SYSCAT.INDEXES TO USER svcfndb2gcd@ENV@;
GRANT SELECT ON SYSIBM.SYSDUMMY1 TO USER svcfndb2gcd@ENV@;
GRANT USAGE ON WORKLOAD SYSDEFAULTUSERWORKLOAD TO USER svcfndb2gcd@ENV@;
GRANT USE OF TABLESPACE @TEMP_TS@ TO USER svcfndb2gcd@ENV@;

-- 4.3 svcfndb2logistik@ENV@ (Logistik Object Store)
GRANT CONNECT ON DATABASE TO USER svcfndb2logistik@ENV@;
GRANT CREATETAB ON DATABASE TO USER svcfndb2logistik@ENV@;
GRANT IMPLICIT_SCHEMA ON DATABASE TO USER svcfndb2logistik@ENV@;
GRANT SELECT ON SYSIBM.SYSVERSIONS TO USER svcfndb2logistik@ENV@;
GRANT SELECT ON SYSCAT.DATATYPES TO USER svcfndb2logistik@ENV@;
GRANT SELECT ON SYSCAT.INDEXES TO USER svcfndb2logistik@ENV@;
GRANT SELECT ON SYSIBM.SYSDUMMY1 TO USER svcfndb2logistik@ENV@;
GRANT USAGE ON WORKLOAD SYSDEFAULTUSERWORKLOAD TO USER svcfndb2logistik@ENV@;
GRANT USE OF TABLESPACE @TEMP_TS@ TO USER svcfndb2logistik@ENV@;

-- 4.4 svcfndb2person@ENV@ (Person Object Store)
GRANT CONNECT ON DATABASE TO USER svcfndb2person@ENV@;
GRANT CREATETAB ON DATABASE TO USER svcfndb2person@ENV@;
GRANT IMPLICIT_SCHEMA ON DATABASE TO USER svcfndb2person@ENV@;
GRANT SELECT ON SYSIBM.SYSVERSIONS TO USER svcfndb2person@ENV@;
GRANT SELECT ON SYSCAT.DATATYPES TO USER svcfndb2person@ENV@;
GRANT SELECT ON SYSCAT.INDEXES TO USER svcfndb2person@ENV@;
GRANT SELECT ON SYSIBM.SYSDUMMY1 TO USER svcfndb2person@ENV@;
GRANT USAGE ON WORKLOAD SYSDEFAULTUSERWORKLOAD TO USER svcfndb2person@ENV@;
GRANT USE OF TABLESPACE @TEMP_TS@ TO USER svcfndb2person@ENV@;

-- 4.5 svcfndb2unternehmen@ENV@ (Unternehmen Object Store)
GRANT CONNECT ON DATABASE TO USER svcfndb2unternehmen@ENV@;
GRANT CREATETAB ON DATABASE TO USER svcfndb2unternehmen@ENV@;
GRANT IMPLICIT_SCHEMA ON DATABASE TO USER svcfndb2unternehmen@ENV@;
GRANT SELECT ON SYSIBM.SYSVERSIONS TO USER svcfndb2unternehmen@ENV@;
GRANT SELECT ON SYSCAT.DATATYPES TO USER svcfndb2unternehmen@ENV@;
GRANT SELECT ON SYSCAT.INDEXES TO USER svcfndb2unternehmen@ENV@;
GRANT SELECT ON SYSIBM.SYSDUMMY1 TO USER svcfndb2unternehmen@ENV@;
GRANT USAGE ON WORKLOAD SYSDEFAULTUSERWORKLOAD TO USER svcfndb2unternehmen@ENV@;
GRANT USE OF TABLESPACE @TEMP_TS@ TO USER svcfndb2unternehmen@ENV@;

-- -----------------------------------------------------------------------------
-- 5. Tablespace-Berechtigungen (USE OF TABLESPACE) fuer Object Stores
-- -----------------------------------------------------------------------------

-- 5.1 PERSON Object Store Tablespace-Rechte
GRANT USE OF TABLESPACE TS_PERSON_DAT_@ENV@   TO USER svcfndb2person@ENV@;
GRANT USE OF TABLESPACE TS_PERSON_IND_@ENV@   TO USER svcfndb2person@ENV@;
GRANT USE OF TABLESPACE TS_PERSON_LOB_@ENV@   TO USER svcfndb2person@ENV@;
GRANT USE OF TABLESPACE TS_PERSONVW_DAT_@ENV@ TO USER svcfndb2person@ENV@;
GRANT USE OF TABLESPACE TS_PERSONVW_IND_@ENV@ TO USER svcfndb2person@ENV@;
GRANT USE OF TABLESPACE TS_PERSONVW_LOB_@ENV@ TO USER svcfndb2person@ENV@;

-- 5.2 LOGISTIK Object Store Tablespace-Rechte
GRANT USE OF TABLESPACE TS_LOGI_DATA_@ENV@    TO USER svcfndb2logistik@ENV@;
GRANT USE OF TABLESPACE TS_LOGI_INDEX_@ENV@   TO USER svcfndb2logistik@ENV@;
GRANT USE OF TABLESPACE TS_LOGI_LOB_@ENV@     TO USER svcfndb2logistik@ENV@;

-- 5.3 UNTERNEHMEN Object Store Tablespace-Rechte
GRANT USE OF TABLESPACE TS_UNTER_DATA_@ENV@   TO USER svcfndb2unternehmen@ENV@;
GRANT USE OF TABLESPACE TS_UNTER_INDEX_@ENV@  TO USER svcfndb2unternehmen@ENV@;
GRANT USE OF TABLESPACE TS_UNTER_LOB_@ENV@    TO USER svcfndb2unternehmen@ENV@;

-- -----------------------------------------------------------------------------
-- 6. Transaktion abschliessen & Verbindung trennen
-- -----------------------------------------------------------------------------
COMMIT;

CONNECT RESET;
