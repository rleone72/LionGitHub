#!/bin/sh
#For ICP4A
export NAMESPACE=${JOB_NAMESPACE}

echo "Pre-install Script ran successfully"
