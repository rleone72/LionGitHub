# IBM Cloud Pak for Business Automation 21.0.2 on Certified Kubernetes

This repository includes folders and resources to help you install the IBM Cloud Pak for Business Automation capabilities. Installation of the capabilities is done with the Cloud Pak operator.

For information and instructions to install, upgrade, manage, and administer Cloud Pak for Business Automation, go to [IBM Knowledge Center](https://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.install/topics/con_installing.html).

Legal notice for users of this repository [legal-notice.md](legal-notice.md).
